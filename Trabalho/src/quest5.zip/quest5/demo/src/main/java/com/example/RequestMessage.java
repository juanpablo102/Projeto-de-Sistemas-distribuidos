package com.example;
public class RequestMessage {
    int messageType = 0; 
    int requestID;
    String objectReference; 
    String methodID;      
    String arguments;     
}