package com.example;
public class ReplyMessage {
    int messageType = 1; 
    int requestID;       
    String result;       
}